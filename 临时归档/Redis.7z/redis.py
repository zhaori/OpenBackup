from os import system

system("redis.exe redis.conf")
