#文件格式
Photo=[".jpeg",".JPEG",".TIFF",".tiff",".RAW",".raw",".BMP",".bmp",".GIF",".gif",".PNG",".png"]
Movie=[".mp4",".RMVB",".rmvb",".AVI",".avi"]
Muic=[".mp3",".ape",".WMA",".wma",".FLAC",".flac",".AAC",".aac"]
Text=[".PDF",".pdf",".txt",".doc",".docx",".xlsx",".xlx",".pptx",".py",".pyc",".zip","rar",".tar",".iso","gzip"]
