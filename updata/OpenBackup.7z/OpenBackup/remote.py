import os
import time
from multiprocessing import cpu_count
from threading import Thread

from Lib.PySSH import PYSCP

"""
根据CPU核数来开启进程，用进程管理多线程，这里开启的多进程数量为CPU核数的2倍
"""
CPU_CORE = cpu_count() * 2


# split_file(source=r'1.zip', folder= r'.\Temp', read_size=10*1024*1024).excision()

class remote_file(object):
    def __init__(self, temp=None):
        if temp is None:
            temp = r'.\Temp'
        self.temp = temp  # 存放分割后的文件存放路径
        self.file_num = None  # 获取分割的文件有多少
        self.file_list = []  # 分割的文件绝对路径

    def getfile_info(self):
        # 统计文件信息
        for root, dirs, file in os.walk(self.temp):
            self.file_num = len(file)
            self.file_list = [os.path.join(root, f) for f in file]
        # print(self.file_num, self.file_list)
        return self.file_num, self.file_list

    def up_file(self, source: list):
        thread_list = []
        for s in source:
            thread_list.append(
                Thread(target=PYSCP().scp_up,
                       args=(s,)))
        for t in thread_list:
            t.start()
        for t in thread_list:
            t.join()

    def allocation_task(self):
        task_num = self.file_num // CPU_CORE
        process_task = []
        # for i in range(0, CPU_CORE):
        # process_task.append(Process(target=self.up_file, args=(self.file_list[i * 32: i * 32 + 32],)))
        # process_task.append(Process(target=self.up_file, args=(self.file_list[task_num * CPU_CORE: self.file_num],)))
        # print(task_num)
        # for p in process_task:
        #    p.run()

        # num = [i for i in range(0, self.file_num, task_num)]
        # print(num)
        # print(self.file_list[0:32])
        # print(self.file_list[32:64])
        # print(self.file_list[num[0]: num[0+1]])


if __name__ == '__main__':
    r = remote_file()
    r.getfile_info()
    file_list = []
    for root, dirs, file in os.walk('./Temp'):
        file_list = [os.path.join(root, f).replace('/', '\\') for f in file]
    e = time.time()
    r.up_file(file_list)
    print(time.time() - e)
# for i in os.listdir('./Temp'):
#     PYSCP().scp_up(os.path.join('./Temp', i))


# 154.4620702266693
