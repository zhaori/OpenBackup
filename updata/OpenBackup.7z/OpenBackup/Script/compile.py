import os
from threading import Thread

"""
:compile_list 编译文件的路径，可以为绝对路径或相对路径，在路径前加r，以python解释器分辨为字符串
"""
"""
r".\source\listen_service.pyw",
r".\source\Main.pyw",
r".\source\random_key.pyw",
r".\source\watch_listen.pyw"
"""
compile_list = [
    r'..\work\begin_calendar.py',
    r'..\work\end_calendar.py'
]


def get_compile(file, icon):
    os.system(f"pyinstaller -F {file} -i {icon} --noconsole")


thread_list = [Thread(target=get_compile, args=(i, r'..\logo\应用.ico')) for i in compile_list]
for i in thread_list:
    i.start()
for i in thread_list:
    i.join()

# 做一点清理工作
try:
    for spec, build_info in zip(os.listdir('./'), os.listdir('./build')):
        file, suffix = os.path.splitext(spec)
        if suffix == '.spec':
            os.remove(spec)
        if os.path.isfile(build_info):
            os.remove(build_info)
        elif os.path.isdir(build_info):
            os.rmdir(build_info)
except FileNotFoundError:
    pass
