import urllib.request
update_url = 'https://'