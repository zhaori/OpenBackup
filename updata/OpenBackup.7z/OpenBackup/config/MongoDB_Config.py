# MongoDB
mongo_host = "127.0.0.1"
mongo_port = 27017
