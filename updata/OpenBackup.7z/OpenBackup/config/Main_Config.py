import os
from ctypes import windll
from tkinter.messagebox import showinfo
from Lib.MongoDBSever import Mongodb_server
from config.MongoDB_Config import *
from threading import Thread
windll.shell32.SetCurrentProcessExplicitAppUserModelID('version')

tk_title = 'OpenBackup 0.1 beta'
logo = r'./logo/应用.ico'

# 加载任务
mongodb = Mongodb_server(mongo_host, mongo_port)
try:
    READ_DB = mongodb.search_one('tasks', mongodb.search_table('select')[0], {"_id": 0, 'folder': 1})['folder']
except Exception:
    READ_DB = '/'

# 监听文件夹
listen_dir = [
    READ_DB
]


def about_main():
    showinfo(tk_title, '        本程序遵守GPL 3.0协议开源\n '
                       '                 @ Python3.7  \n '
                       '                        Tkinter  \n '
                       '                       OpenSSL  \n '
                       '                            7z  \n '
                       ' https://github.com/zhaori/OpenBackup')


def read_help():
    os.system(r'.\Script\Notepad2.exe .\doc\help.txt')


def ssh_options():
    def open_config():
        os.system(r'Notepad2 ./config/Net_Config.py')
    t = Thread(target=open_config)
    t.start()
